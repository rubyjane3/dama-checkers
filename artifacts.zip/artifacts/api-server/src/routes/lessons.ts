import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { lessonsTable, lessonProgressTable } from "@workspace/db";
import { GetLessonParams, UpdateLessonProgressParams, UpdateLessonProgressBody } from "@workspace/api-zod";
import { eq, and } from "drizzle-orm";
import { getOrCreateUser } from "./users";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

router.get("/", async (req, res) => {
  try {
    const lessons = await db.select().from(lessonsTable).orderBy(lessonsTable.order);
    res.json(lessons);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/my-progress", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const user = await getOrCreateUser(userId!);
    const progress = await db.select().from(lessonProgressTable).where(eq(lessonProgressTable.userId, user.id));
    res.json(progress);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const parsed = GetLessonParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) return res.status(400).json({ error: "Invalid id" });

    const lesson = await db.query.lessonsTable.findFirst({ where: eq(lessonsTable.id, parsed.data.id) });
    if (!lesson) return res.status(404).json({ error: "Lesson not found" });
    res.json(lesson);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id/progress", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const idParsed = UpdateLessonProgressParams.safeParse({ id: Number(req.params.id) });
    if (!idParsed.success) return res.status(400).json({ error: "Invalid id" });

    const parsed = UpdateLessonProgressBody.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid data" });

    const user = await getOrCreateUser(userId!);
    const lesson = await db.query.lessonsTable.findFirst({ where: eq(lessonsTable.id, idParsed.data.id) });
    if (!lesson) return res.status(404).json({ error: "Lesson not found" });

    let progress = await db.query.lessonProgressTable.findFirst({
      where: and(eq(lessonProgressTable.userId, user.id), eq(lessonProgressTable.lessonId, idParsed.data.id)),
    });

    const updateData: any = { stepsCompleted: parsed.data.stepsCompleted };
    if (parsed.data.completed) {
      updateData.completed = true;
      updateData.completedAt = new Date();
    }

    if (progress) {
      const [updated] = await db.update(lessonProgressTable)
        .set(updateData)
        .where(and(eq(lessonProgressTable.userId, user.id), eq(lessonProgressTable.lessonId, idParsed.data.id)))
        .returning();
      res.json(updated);
    } else {
      const [created] = await db.insert(lessonProgressTable).values({
        userId: user.id,
        lessonId: idParsed.data.id,
        ...updateData,
      }).returning();
      res.json(created);
    }
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
