import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { roomsTable } from "@workspace/db";
import { CreateRoomBody, GetRoomParams, UpdateRoomParams, UpdateRoomBody } from "@workspace/api-zod";
import { eq } from "drizzle-orm";
import { getOrCreateUser } from "./users";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

function generateCode(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

router.post("/", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const user = await getOrCreateUser(userId!);

    let code = generateCode();
    let exists = await db.query.roomsTable.findFirst({ where: eq(roomsTable.code, code) });
    while (exists) {
      code = generateCode();
      exists = await db.query.roomsTable.findFirst({ where: eq(roomsTable.code, code) });
    }

    const [room] = await db.insert(roomsTable).values({
      code,
      hostUserId: user.id,
      status: "waiting",
    }).returning();
    res.status(201).json(room);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:code", async (req, res) => {
  try {
    const parsed = GetRoomParams.safeParse({ code: req.params.code });
    if (!parsed.success) return res.status(400).json({ error: "Invalid code" });

    const room = await db.query.roomsTable.findFirst({ where: eq(roomsTable.code, parsed.data.code) });
    if (!room) return res.status(404).json({ error: "Room not found" });
    res.json(room);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:code", requireAuth, async (req, res) => {
  try {
    const parsed = UpdateRoomBody.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid data" });

    const room = await db.query.roomsTable.findFirst({ where: eq(roomsTable.code, req.params.code) });
    if (!room) return res.status(404).json({ error: "Room not found" });

    const updateData: Partial<typeof room> = {};
    if (parsed.data.guestUserId !== undefined) updateData.guestUserId = parsed.data.guestUserId;
    if (parsed.data.status !== undefined) updateData.status = parsed.data.status;
    if (parsed.data.winnerId !== undefined) updateData.winnerId = parsed.data.winnerId;

    const [updated] = await db.update(roomsTable).set(updateData).where(eq(roomsTable.code, req.params.code)).returning();
    res.json(updated);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
