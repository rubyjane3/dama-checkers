import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import gamesRouter from "./games";
import roomsRouter from "./rooms";
import leaderboardRouter from "./leaderboard";
import lessonsRouter from "./lessons";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/users", usersRouter);
router.use("/games", gamesRouter);
router.use("/rooms", roomsRouter);
router.use("/leaderboard", leaderboardRouter);
router.use("/lessons", lessonsRouter);

export default router;
