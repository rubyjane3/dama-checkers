import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, gamesTable } from "@workspace/db";
import { GetLeaderboardQueryParams } from "@workspace/api-zod";
import { eq, sql, desc, count } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const parsed = GetLeaderboardQueryParams.safeParse(req.query);
    const limit = parsed.success ? (parsed.data.limit ?? 20) : 20;

    const users = await db.select({
      id: usersTable.id,
      username: usersTable.username,
      avatarUrl: usersTable.avatarUrl,
      rating: usersTable.rating,
      city: usersTable.city,
    }).from(usersTable)
      .orderBy(desc(usersTable.rating))
      .limit(limit);

    const withWins = await Promise.all(users.map(async (u, idx) => {
      const wins = await db.select({ count: count() }).from(gamesTable)
        .where(eq(gamesTable.userId, u.id));
      const winCount = Number(wins[0]?.count ?? 0);
      return {
        rank: idx + 1,
        userId: u.id,
        username: u.username,
        avatarUrl: u.avatarUrl,
        wins: winCount,
        rating: u.rating,
        city: u.city,
      };
    }));

    res.json(withWins);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/summary", async (req, res) => {
  try {
    const totalPlayersResult = await db.select({ count: count() }).from(usersTable);
    const totalPlayers = Number(totalPlayersResult[0]?.count ?? 0);

    const avgRatingResult = await db.select({ avg: sql<number>`avg(${usersTable.rating})` }).from(usersTable);
    const avgRating = Number(avgRatingResult[0]?.avg ?? 1200);

    const topCityResult = await db.select({
      city: usersTable.city,
      cnt: count(),
    }).from(usersTable)
      .groupBy(usersTable.city)
      .orderBy(desc(count()))
      .limit(1);
    const topCity = topCityResult[0]?.city ?? null;

    const totalGamesResult = await db.select({ count: count() }).from(gamesTable);
    const totalGamesPlayed = Number(totalGamesResult[0]?.count ?? 0);

    res.json({ totalPlayers, avgRating, topCity, totalGamesPlayed });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
