import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { usersTable, gamesTable } from "@workspace/db";
import { CreateGameBody, UpdateGameBody, GetGameParams, UpdateGameParams, GetGameHistoryQueryParams } from "@workspace/api-zod";
import { eq, desc, and } from "drizzle-orm";
import { getOrCreateUser } from "./users";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

router.post("/", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const parsed = CreateGameBody.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid data" });

    const user = await getOrCreateUser(userId!);
    const [game] = await db.insert(gamesTable).values({
      userId: user.id,
      mode: parsed.data.mode,
      difficulty: parsed.data.difficulty ?? null,
      roomId: parsed.data.roomId ?? null,
      result: null,
      moveCount: 0,
    }).returning();
    res.status(201).json(game);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/history", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const parsed = GetGameHistoryQueryParams.safeParse(req.query);
    const limit = parsed.success ? (parsed.data.limit ?? 20) : 20;
    const offset = parsed.success ? (parsed.data.offset ?? 0) : 0;

    const user = await getOrCreateUser(userId!);
    const games = await db.select().from(gamesTable)
      .where(eq(gamesTable.userId, user.id))
      .orderBy(desc(gamesTable.createdAt))
      .limit(limit)
      .offset(offset);
    res.json(games);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id", requireAuth, async (req, res) => {
  try {
    const parsed = GetGameParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) return res.status(400).json({ error: "Invalid id" });

    const game = await db.query.gamesTable.findFirst({ where: eq(gamesTable.id, parsed.data.id) });
    if (!game) return res.status(404).json({ error: "Game not found" });
    res.json(game);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const idParsed = UpdateGameParams.safeParse({ id: Number(req.params.id) });
    if (!idParsed.success) return res.status(400).json({ error: "Invalid id" });

    const parsed = UpdateGameBody.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid data" });

    const user = await getOrCreateUser(userId!);
    const game = await db.query.gamesTable.findFirst({ where: eq(gamesTable.id, idParsed.data.id) });
    if (!game) return res.status(404).json({ error: "Game not found" });
    if (game.userId !== user.id) return res.status(403).json({ error: "Forbidden" });

    const updateData: Partial<typeof game> = {};
    if (parsed.data.result !== undefined) updateData.result = parsed.data.result;
    if (parsed.data.moveCount !== undefined) updateData.moveCount = parsed.data.moveCount;
    if (parsed.data.durationSeconds !== undefined) updateData.durationSeconds = parsed.data.durationSeconds;

    // Update user XP and rating on result
    if (parsed.data.result === "win") {
      await db.update(usersTable).set({ xp: user.xp + 50, rating: user.rating + 15 }).where(eq(usersTable.id, user.id));
    } else if (parsed.data.result === "loss") {
      await db.update(usersTable).set({ xp: user.xp + 10, rating: Math.max(800, user.rating - 10) }).where(eq(usersTable.id, user.id));
    } else if (parsed.data.result === "draw") {
      await db.update(usersTable).set({ xp: user.xp + 25 }).where(eq(usersTable.id, user.id));
    }

    const [updated] = await db.update(gamesTable).set(updateData).where(eq(gamesTable.id, idParsed.data.id)).returning();
    res.json(updated);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
