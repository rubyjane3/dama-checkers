import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { usersTable, gamesTable } from "@workspace/db";
import { UpdateMeBody } from "@workspace/api-zod";
import { eq, sql } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

async function getOrCreateUser(clerkId: string) {
  let user = await db.query.usersTable.findFirst({ where: eq(usersTable.clerkId, clerkId) });
  if (!user) {
    const username = `player_${clerkId.slice(-6)}`;
    [user] = await db.insert(usersTable).values({ clerkId, username }).returning();
  }
  return user;
}

router.get("/me", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const user = await getOrCreateUser(userId!);
    res.json(user);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/me", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const parsed = UpdateMeBody.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid data" });

    const user = await getOrCreateUser(userId!);
    const [updated] = await db.update(usersTable)
      .set(parsed.data)
      .where(eq(usersTable.id, user.id))
      .returning();
    res.json(updated);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/me/stats", requireAuth, async (req, res) => {
  try {
    const { userId } = getAuth(req);
    const user = await getOrCreateUser(userId!);

    const games = await db.select().from(gamesTable).where(eq(gamesTable.userId, user.id));
    const wins = games.filter(g => g.result === "win").length;
    const losses = games.filter(g => g.result === "loss").length;
    const draws = games.filter(g => g.result === "draw").length;
    const totalGames = games.length;
    const winRate = totalGames > 0 ? wins / totalGames : 0;

    // streak: count consecutive wins from the end
    let streak = 0;
    for (let i = games.length - 1; i >= 0; i--) {
      if (games[i].result === "win") streak++;
      else break;
    }

    res.json({ wins, losses, draws, streak, totalGames, winRate });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export { getOrCreateUser };
export default router;
