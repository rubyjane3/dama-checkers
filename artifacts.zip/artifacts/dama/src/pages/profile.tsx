import { useState } from "react";
import { useLocation, Redirect } from "wouter";
import { useUser, useClerk, Show } from "@clerk/react";
import { useGetMe, useGetMyStats, useGetGameHistory, useUpdateMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const modeLabel: Record<string, string> = {
  vs_ai: "vs AI",
  vs_friend: "vs Друг",
  kids: "Детский",
};

const resultLabel: Record<string, { text: string; color: string }> = {
  win: { text: "Победа", color: "text-primary" },
  loss: { text: "Поражение", color: "text-secondary" },
  draw: { text: "Ничья", color: "text-muted-foreground" },
};

const CITIES = ["Алматы", "Астана", "Шымкент", "Актобе", "Павлодар", "Тараз", "Усть-Каменогорск", "Семей", "Атырау", "Кызылорда", "Другой"];

function EditProfile({ onClose }: { onClose: () => void }) {
  const { data: profile } = useGetMe();
  const updateMe = useUpdateMe();
  const qc = useQueryClient();

  const [username, setUsername] = useState(profile?.username ?? "");
  const [city, setCity] = useState(profile?.city ?? "");
  const [customCity, setCustomCity] = useState("");
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    const finalCity = city === "Другой" ? customCity : city;
    updateMe.mutate(
      { data: { username: username.trim() || undefined, city: finalCity || undefined } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getGetMeQueryKey() });
          setSaved(true);
          setTimeout(() => { setSaved(false); onClose(); }, 800);
        },
      }
    );
  };

  return (
    <div className="p-5 rounded-2xl bg-card border border-primary/20 mb-6">
      <h2 className="font-serif text-lg font-bold mb-5">Редактировать профиль</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-xs text-muted-foreground mb-1.5">Имя игрока</label>
          <Input
            data-testid="input-username"
            value={username}
            onChange={e => setUsername(e.target.value)}
            placeholder="Введите имя"
            maxLength={30}
          />
          <p className="text-xs text-muted-foreground mt-1">Отображается в рейтинге и в игре</p>
        </div>
        <div>
          <label className="block text-xs text-muted-foreground mb-1.5">Город</label>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {CITIES.map(c => (
              <button
                key={c}
                onClick={() => setCity(c)}
                className={`py-2 px-3 rounded-lg text-xs font-medium transition-all border ${
                  city === c
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          {city === "Другой" && (
            <Input
              className="mt-3"
              placeholder="Введите город"
              value={customCity}
              onChange={e => setCustomCity(e.target.value)}
              maxLength={40}
            />
          )}
        </div>
      </div>
      <div className="flex gap-3 mt-5">
        <Button
          data-testid="button-save-profile"
          onClick={handleSave}
          disabled={updateMe.isPending || (!username.trim() && !city)}
          className="flex-1 font-serif"
        >
          {saved ? "Сохранено ✓" : updateMe.isPending ? "Сохраняем…" : "Сохранить"}
        </Button>
        <Button variant="outline" onClick={onClose} className="flex-1">
          Отмена
        </Button>
      </div>
    </div>
  );
}

export default function Profile() {
  const [, setLocation] = useLocation();
  const { user } = useUser();
  const { signOut } = useClerk();
  const [editing, setEditing] = useState(false);

  const { data: profile, isLoading: profileLoading } = useGetMe();
  const { data: stats, isLoading: statsLoading } = useGetMyStats();
  const { data: history, isLoading: historyLoading } = useGetGameHistory({ limit: 10 });

  const displayName = profile?.username ?? user?.fullName ?? "Игрок";
  const initial = displayName[0]?.toUpperCase() ?? "И";

  return (
    <>
      <Show when="signed-out">
        <Redirect to="/sign-in" />
      </Show>
      <Show when="signed-in">
        <div className="min-h-screen bg-background text-foreground">
          <div className="flex items-center justify-between px-6 py-4 border-b border-border/40">
            <button onClick={() => setLocation("/")} className="font-serif text-xl text-primary tracking-widest">DAMA</button>
            <div className="flex items-center gap-4">
              <button onClick={() => setLocation("/play")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Играть
              </button>
              <button
                data-testid="button-sign-out"
                onClick={() => signOut(() => setLocation("/"))}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Выйти
              </button>
            </div>
          </div>

          <div className="max-w-3xl mx-auto px-6 py-10">
            {/* Profile header */}
            <div className="flex items-start gap-5 mb-6">
              <div className="w-16 h-16 rounded-full bg-primary/20 border-2 border-primary/40 flex items-center justify-center shrink-0 overflow-hidden">
                {user?.imageUrl ? (
                  <img src={user.imageUrl} alt="avatar" className="w-full h-full object-cover" />
                ) : (
                  <span className="font-serif text-2xl text-primary font-bold">{initial}</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                {profileLoading ? (
                  <Skeleton className="h-7 w-48 mb-2" />
                ) : (
                  <h1 data-testid="text-username" className="font-serif text-2xl font-bold truncate">
                    {displayName}
                  </h1>
                )}
                <div className="flex flex-wrap gap-3 mt-2">
                  {profile?.city && (
                    <span className="text-xs text-muted-foreground">{profile.city}</span>
                  )}
                  {profile?.isPro && (
                    <span className="inline-flex px-2 py-0.5 rounded-full bg-primary/20 text-primary text-xs font-bold border border-primary/30">
                      PRO
                    </span>
                  )}
                  <span className="text-xs text-muted-foreground">
                    Рейтинг: <span className="text-primary font-serif font-bold">{profile?.rating ?? 1200}</span>
                  </span>
                  <span className="text-xs text-muted-foreground">
                    XP: <span className="text-foreground font-medium">{profile?.xp ?? 0}</span>
                  </span>
                </div>
              </div>
              <div className="flex flex-col gap-2 shrink-0">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => setEditing(e => !e)}
                >
                  {editing ? "Закрыть" : "Изменить профиль"}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs text-muted-foreground"
                  onClick={() => setLocation("/pro")}
                >
                  {profile?.isPro ? "Pro активен" : "Upgrade Pro"}
                </Button>
              </div>
            </div>

            {/* Inline edit form */}
            {editing && <EditProfile onClose={() => setEditing(false)} />}

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-10">
              {statsLoading ? (
                Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)
              ) : stats ? (
                [
                  { label: "Победы", value: stats.wins, color: "text-primary" },
                  { label: "Поражения", value: stats.losses, color: "text-secondary" },
                  { label: "Ничьи", value: stats.draws, color: "text-muted-foreground" },
                  { label: "Серия побед", value: stats.streak, color: "text-primary" },
                  { label: "Всего игр", value: stats.totalGames, color: "text-foreground" },
                  { label: "Процент побед", value: `${Math.round(stats.winRate * 100)}%`, color: "text-primary" },
                ].map(s => (
                  <div key={s.label} className="p-4 rounded-xl bg-card border border-border text-center">
                    <div className={`font-serif text-2xl font-bold ${s.color}`}>{s.value}</div>
                    <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
                  </div>
                ))
              ) : null}
            </div>

            {/* Game history */}
            <div>
              <h2 className="font-serif text-xl mb-4">История игр</h2>
              {historyLoading ? (
                Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 w-full mb-2 rounded-xl" />)
              ) : history?.length === 0 ? (
                <div className="p-8 rounded-2xl border border-border/50 bg-card text-center">
                  <p className="text-muted-foreground text-sm">Нет сыгранных игр</p>
                  <button onClick={() => setLocation("/play")} className="mt-3 text-primary text-sm hover:underline">
                    Начать первую игру
                  </button>
                </div>
              ) : (
                <div className="rounded-2xl border border-border overflow-hidden">
                  {history?.map((game, i) => {
                    const res = game.result ? resultLabel[game.result] : null;
                    return (
                      <div
                        key={game.id}
                        data-testid={`history-row-${game.id}`}
                        className={`flex items-center justify-between px-4 py-3.5 ${i > 0 ? "border-t border-border" : ""} hover:bg-muted/30 transition-colors`}
                      >
                        <div>
                          <div className="font-medium text-sm">{modeLabel[game.mode] ?? game.mode}</div>
                          <div className="text-xs text-muted-foreground">
                            {game.difficulty ? `Сложность: ${game.difficulty} · ` : ""}{game.moveCount} ходов
                          </div>
                        </div>
                        <div className="text-right">
                          {res
                            ? <div className={`text-sm font-medium font-serif ${res.color}`}>{res.text}</div>
                            : <div className="text-sm text-muted-foreground">В процессе</div>
                          }
                          <div className="text-xs text-muted-foreground">
                            {new Date(game.createdAt).toLocaleDateString("ru")}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </Show>
    </>
  );
}
