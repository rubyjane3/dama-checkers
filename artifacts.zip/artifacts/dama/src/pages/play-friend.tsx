import { useState } from "react";
import { useLocation } from "wouter";
import { Show } from "@clerk/react";
import { useCreateRoom, useGetRoom } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function PlayFriend() {
  const [, setLocation] = useLocation();
  const [roomCode, setRoomCode] = useState("");
  const [createdCode, setCreatedCode] = useState<string | null>(null);
  const [joinError, setJoinError] = useState("");
  const [copied, setCopied] = useState(false);

  const createRoom = useCreateRoom();

  const handleCreate = () => {
    createRoom.mutate({ data: {} }, {
      onSuccess: (room) => setCreatedCode(room.code),
    });
  };

  const handleJoin = () => {
    if (!roomCode.trim()) return;
    setLocation(`/room/${roomCode.trim().toUpperCase()}`);
  };

  const handleCopy = () => {
    if (!createdCode) return;
    const link = `${window.location.origin}/play/friend?code=${createdCode}`;
    navigator.clipboard.writeText(link).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <div className="flex items-center justify-between px-6 py-4 border-b border-border/40">
        <button onClick={() => setLocation("/")} className="font-serif text-xl text-primary tracking-widest">DAMA</button>
        <button onClick={() => setLocation("/play")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
          Vs AI
        </button>
      </div>

      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="text-center mb-10">
            <div className="text-primary text-4xl font-serif mb-3">⟡</div>
            <h1 className="font-serif text-3xl font-bold mb-2">Игра с другом</h1>
            <p className="text-muted-foreground text-sm">Создай комнату и поделись ссылкой, или введи код друга</p>
          </div>

          <Show when="signed-out">
            <div className="p-6 rounded-2xl border border-border/50 bg-card text-center mb-6">
              <p className="text-muted-foreground text-sm mb-4">Войдите в аккаунт чтобы создать комнату</p>
              <Button onClick={() => setLocation("/sign-in")} className="font-serif">Войти</Button>
            </div>
          </Show>

          <div className="space-y-4">
            {/* Create room */}
            <Show when="signed-in">
              <div className="p-6 rounded-2xl border border-border/50 bg-card">
                <h2 className="font-serif text-lg mb-4">Создать комнату</h2>
                {!createdCode ? (
                  <Button
                    data-testid="button-create-room"
                    onClick={handleCreate}
                    className="w-full font-serif"
                    disabled={createRoom.isPending}
                  >
                    {createRoom.isPending ? "Создаём..." : "Создать новую комнату"}
                  </Button>
                ) : (
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-muted border border-border text-center">
                      <div className="text-xs text-muted-foreground mb-1">Код комнаты</div>
                      <div className="font-serif text-3xl font-bold text-primary tracking-widest">{createdCode}</div>
                    </div>
                    <button
                      data-testid="button-copy-link"
                      onClick={handleCopy}
                      className="w-full py-3 rounded-xl border border-border text-sm hover:bg-muted/50 transition-all"
                    >
                      {copied ? "Скопировано!" : "Скопировать ссылку"}
                    </button>
                    <p className="text-xs text-muted-foreground text-center">
                      Поделитесь кодом или ссылкой с другом. Ожидайте подключения...
                    </p>
                    <div className="flex items-center justify-center gap-2 py-2">
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                      <span className="text-sm text-muted-foreground">Ожидание игрока...</span>
                    </div>
                  </div>
                )}
              </div>
            </Show>

            {/* Join room */}
            <div className="p-6 rounded-2xl border border-border/50 bg-card">
              <h2 className="font-serif text-lg mb-4">Присоединиться по коду</h2>
              <div className="flex gap-3">
                <Input
                  data-testid="input-room-code"
                  placeholder="Введите код (напр. AB12CD)"
                  value={roomCode}
                  onChange={e => setRoomCode(e.target.value.toUpperCase())}
                  className="flex-1 font-serif tracking-widest uppercase"
                  maxLength={6}
                />
                <Button
                  data-testid="button-join-room"
                  onClick={handleJoin}
                  disabled={!roomCode.trim()}
                  variant="outline"
                  className="font-serif"
                >
                  Войти
                </Button>
              </div>
              {joinError && <p className="text-xs text-destructive mt-2">{joinError}</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
