import { useLocation } from "wouter";
import { useGetLessons, useGetMyLessonProgress, getGetLessonsQueryKey, getGetMyLessonProgressQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Show } from "@clerk/react";

const difficultyLabel: Record<string, string> = {
  beginner: "Начинающий",
  easy: "Лёгкий",
  medium: "Средний",
};

const difficultyColor: Record<string, string> = {
  beginner: "bg-primary/20 text-primary border-primary/30",
  easy: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  medium: "bg-secondary/20 text-secondary border-secondary/30",
};

export default function Kids() {
  const [, setLocation] = useLocation();
  const { data: lessons, isLoading } = useGetLessons();
  const { data: progress } = useGetMyLessonProgress();

  const getProgress = (lessonId: number) => progress?.find(p => p.lessonId === lessonId);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border/40">
        <button onClick={() => setLocation("/")} className="font-serif text-xl text-primary tracking-widest">DAMA</button>
        <button onClick={() => setLocation("/play")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
          Играть
        </button>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Header section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-medium mb-6 tracking-wider">
            ДЕТСКИЙ ОБУЧАЮЩИЙ РЕЖИМ
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl font-bold mb-4">
            Учись играть в шашки
          </h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            6 пошаговых уроков, которые научат тебя всем секретам русских шашек. От первого хода до дамки!
          </p>
        </div>

        {/* Progress bar (if signed in) */}
        <Show when="signed-in">
          {progress && (
            <div className="mb-8 p-4 rounded-xl bg-card border border-border">
              <div className="flex items-center justify-between mb-2 text-sm">
                <span className="text-muted-foreground">Прогресс обучения</span>
                <span className="font-serif text-primary">
                  {progress.filter(p => p.completed).length} / {lessons?.length ?? 6} уроков
                </span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500"
                  style={{ width: `${lessons?.length ? (progress.filter(p => p.completed).length / lessons.length) * 100 : 0}%` }}
                />
              </div>
            </div>
          )}
        </Show>

        {/* Lessons grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-36 rounded-2xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {lessons?.map((lesson) => {
              const prog = getProgress(lesson.id);
              const isCompleted = prog?.completed;
              const stepsCompleted = prog?.stepsCompleted ?? 0;
              const pct = lesson.totalSteps ? (stepsCompleted / lesson.totalSteps) * 100 : 0;

              return (
                <div
                  key={lesson.id}
                  data-testid={`lesson-card-${lesson.id}`}
                  className="p-6 rounded-2xl border border-border/50 bg-card hover:border-primary/40 transition-all group cursor-pointer relative overflow-hidden"
                  onClick={() => setLocation(`/kids/lesson/${lesson.id}`)}
                >
                  {isCompleted && (
                    <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-primary text-xs font-bold">✓</span>
                    </div>
                  )}

                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0">
                      <span className="font-serif text-primary text-sm font-bold">{lesson.order}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-serif text-base font-bold mb-1 group-hover:text-primary transition-colors">
                        {lesson.title}
                      </h3>
                      <span className={`inline-flex px-2 py-0.5 rounded-full border text-xs font-medium ${difficultyColor[lesson.difficulty]}`}>
                        {difficultyLabel[lesson.difficulty]}
                      </span>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-2">
                    {lesson.description}
                  </p>

                  {/* Progress bar */}
                  {stepsCompleted > 0 && (
                    <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  )}

                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{lesson.totalSteps} шагов</span>
                    <span className="text-xs text-primary font-medium group-hover:underline">
                      {isCompleted ? "Повторить" : stepsCompleted > 0 ? "Продолжить" : "Начать"} →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Not signed in note */}
        <Show when="signed-out">
          <div className="mt-8 p-5 rounded-xl border border-border/50 bg-muted/30 text-center">
            <p className="text-sm text-muted-foreground mb-3">
              Войдите в аккаунт чтобы сохранять прогресс уроков
            </p>
            <button
              onClick={() => setLocation("/sign-in")}
              className="px-5 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg"
            >
              Войти
            </button>
          </div>
        </Show>
      </div>
    </div>
  );
}
