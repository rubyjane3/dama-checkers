import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Show } from "@clerk/react";
import {
  initBoard, getAllMoves, getJumps, getMoves, applyMove, getBestMove,
  RED, BLACK,
  isRed, isBlack, isKing, belongs,
  type Board, type Move
} from "@/lib/game";
import { getSkin, getActiveSkinId, type Skin } from "@/lib/skins";
import { useCreateGame, useUpdateGame } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";

type Difficulty = "easy" | "medium" | "hard";

function Piece({
  isPlayer,
  isKingPiece,
  isSelected,
  skin,
}: {
  isPlayer: boolean;
  isKingPiece: boolean;
  isSelected: boolean;
  skin: Skin;
}) {
  const gradient = isPlayer ? skin.playerGradient : skin.aiGradient;
  const shadow = isPlayer ? skin.playerShadow : skin.aiShadow;
  const reflect = isPlayer ? skin.playerReflect : skin.aiReflect;
  const selectedRing = `0 0 0 3px rgba(255,255,255,0.5), 0 0 22px 6px rgba(255,255,255,0.25), ${shadow}`;

  return (
    <div
      className="absolute inset-[12%] rounded-full transition-transform duration-200"
      style={{
        background: gradient,
        boxShadow: isSelected ? selectedRing : shadow,
        transform: isSelected ? "translateY(-6px) scale(1.07)" : undefined,
      }}
    >
      {/* Specular highlight */}
      <div
        className="absolute inset-0 rounded-full pointer-events-none"
        style={{ background: reflect }}
      />
      {/* King crown */}
      {isKingPiece && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span
            className="select-none font-serif font-bold leading-none"
            style={{
              color: skin.kingColor,
              fontSize: "clamp(8px, 2.2cqw, 18px)",
              textShadow: "0 1px 3px rgba(0,0,0,0.6)",
            }}
          >
            ♛
          </span>
        </div>
      )}
    </div>
  );
}

export default function Play() {
  const [, setLocation] = useLocation();
  const [board, setBoard] = useState<Board>(initBoard());
  const [turn, setTurn] = useState<string>(RED);
  const [selected, setSelected] = useState<[number, number] | null>(null);
  const [validMoves, setValidMoves] = useState<Move[]>([]);
  const [gameOver, setGameOver] = useState<string | null>(null);
  const [chainPiece, setChainPiece] = useState<[number, number] | null>(null);
  const [chainCaptured, setChainCaptured] = useState<Set<string>>(new Set());
  const [aiThinking, setAiThinking] = useState(false);
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [moveCount, setMoveCount] = useState(0);
  const [gameId, setGameId] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [skinId] = useState(() => getActiveSkinId());
  const skin = getSkin(skinId);
  const startTime = useRef(Date.now());

  const createGame = useCreateGame();
  const updateGame = useUpdateGame();

  useEffect(() => {
    createGame.mutate({ data: { mode: "vs_ai", difficulty } }, {
      onSuccess: (game) => setGameId(game.id),
    });
    startTime.current = Date.now();
  }, []);

  useEffect(() => {
    if (!selected) { setValidMoves([]); return; }
    const [r, c] = selected;
    if (chainPiece) {
      const [cr, cc] = chainPiece;
      if (cr !== r || cc !== c) { setValidMoves([]); return; }
      setValidMoves(getJumps(board, r, c, RED, chainCaptured));
      return;
    }
    const forced = getAllMoves(board, RED);
    const hasJumps = forced.some(m => m.captured);
    const moves = hasJumps ? getJumps(board, r, c, RED, new Set()) : getMoves(board, r, c, RED);
    setValidMoves(moves);
  }, [selected, board, chainPiece, chainCaptured]);

  useEffect(() => {
    if (turn !== BLACK || gameOver) return;
    setAiThinking(true);

    const doAi = (curBoard: Board, piecePos: [number, number] | null, captSet: Set<string>) => {
      setTimeout(() => {
        let move: Move | null;
        if (piecePos) {
          const chains = getJumps(curBoard, piecePos[0], piecePos[1], BLACK, captSet);
          if (!chains.length) { finalizeAiTurn(curBoard); return; }
          move = chains[Math.floor(Math.random() * chains.length)];
        } else {
          move = getBestMove(curBoard, difficulty);
        }
        if (!move) { finalizeAiTurn(curBoard); return; }
        const newBoard = applyMove(curBoard, move);
        if (move.captured) {
          const newCaptSet = new Set(captSet);
          newCaptSet.add(`${move.captured[0]},${move.captured[1]}`);
          doAi(newBoard, move.to, newCaptSet);
        } else {
          finalizeAiTurn(newBoard);
        }
      }, 600);
    };

    const finalizeAiTurn = (b: Board) => {
      setBoard(b);
      setAiThinking(false);
      if (!getAllMoves(b, RED).length) endGame(b, "loss");
      else { setTurn(RED); setMoveCount(n => n + 1); }
    };

    doAi(board, null, new Set());
  }, [turn, gameOver]);

  function endGame(b: Board, result: "win" | "loss" | "draw") {
    setGameOver(result);
    setShowResult(true);
    if (gameId) {
      const duration = Math.floor((Date.now() - startTime.current) / 1000);
      updateGame.mutate({ id: gameId, data: { result, moveCount, durationSeconds: duration } });
    }
  }

  function handleCellClick(r: number, c: number) {
    if (turn !== RED || gameOver || aiThinking) return;
    const piece = board[r][c];
    if (piece && isRed(piece)) {
      if (chainPiece && (chainPiece[0] !== r || chainPiece[1] !== c)) return;
      setSelected([r, c]);
      return;
    }
    if (selected) {
      const move = validMoves.find(m => m.to[0] === r && m.to[1] === c);
      if (move) {
        const newBoard = applyMove(board, move);
        setBoard(newBoard);
        setMoveCount(n => n + 1);
        if (move.captured) {
          const newCaptSet = new Set(chainCaptured);
          newCaptSet.add(`${move.captured[0]},${move.captured[1]}`);
          const chains = getJumps(newBoard, r, c, RED, newCaptSet);
          if (chains.length) {
            setChainPiece([r, c]);
            setChainCaptured(newCaptSet);
            setSelected([r, c]);
            return;
          }
        }
        setChainPiece(null);
        setChainCaptured(new Set());
        setSelected(null);
        const blackLeft = newBoard.flat().filter(p => p && isBlack(p));
        if (!blackLeft.length || !getAllMoves(newBoard, BLACK).length) {
          endGame(newBoard, "win"); return;
        }
        setTurn(BLACK);
      }
    }
  }

  function resetGame() {
    setBoard(initBoard());
    setTurn(RED);
    setSelected(null);
    setValidMoves([]);
    setGameOver(null);
    setShowResult(false);
    setChainPiece(null);
    setChainCaptured(new Set());
    setMoveCount(0);
    setAiThinking(false);
    startTime.current = Date.now();
    createGame.mutate({ data: { mode: "vs_ai", difficulty } }, {
      onSuccess: (game) => setGameId(game.id),
    });
  }

  const redCount = board.flat().filter(p => p && isRed(p)).length;
  const blackCount = board.flat().filter(p => p && isBlack(p)).length;

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <div className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-border/40">
        <button onClick={() => setLocation("/")} className="font-serif text-xl text-primary tracking-widest">DAMA</button>
        <div className="flex items-center gap-4">
          <button onClick={() => setLocation("/play/friend")} className="text-sm text-muted-foreground hover:text-foreground transition-colors hidden sm:block">
            С другом
          </button>
          <Show when="signed-in">
            <button onClick={() => setLocation("/profile")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Профиль
            </button>
          </Show>
          <button onClick={() => setLocation("/pro")} className="text-sm text-primary hover:text-primary/80 transition-colors">
            Скины
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row items-start justify-center gap-6 p-4 sm:p-6">
        {/* Board */}
        <div className="w-full max-w-[500px] mx-auto lg:mx-0 shrink-0">
          <div
            className="relative rounded-xl overflow-hidden shadow-2xl"
            style={{
              aspectRatio: "1/1",
              border: `4px solid ${skin.boardDark}`,
              boxShadow: skin.glow ?? "0 20px 60px rgba(0,0,0,0.7)",
              containerType: "size",
            }}
          >
            {/* 8×8 grid — fixed rows AND columns so no row expands */}
            <div
              className="w-full h-full"
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(8, 1fr)",
                gridTemplateRows: "repeat(8, 1fr)",
              }}
            >
              {board.map((row, r) =>
                row.map((piece, c) => {
                  const isDark = (r + c) % 2 === 1;
                  const isSelectedCell = selected?.[0] === r && selected?.[1] === c;
                  const isValidTarget = validMoves.some(m => m.to[0] === r && m.to[1] === c);
                  const isChain = chainPiece?.[0] === r && chainPiece?.[1] === c;

                  return (
                    <div
                      key={`${r}-${c}`}
                      data-testid={`cell-${r}-${c}`}
                      className="relative cursor-pointer overflow-hidden"
                      style={{
                        backgroundColor: isChain
                          ? (isDark ? "#3d2b10" : skin.boardLight)
                          : (isDark ? skin.boardDark : skin.boardLight),
                        outline: isDark && isValidTarget ? "2px inset rgba(255,255,255,0.35)" : undefined,
                      }}
                      onClick={() => handleCellClick(r, c)}
                    >
                      {/* Valid move indicator */}
                      {isValidTarget && !piece && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div
                            className="w-[28%] h-[28%] rounded-full animate-pulse"
                            style={{ backgroundColor: "rgba(255,255,255,0.3)" }}
                          />
                        </div>
                      )}
                      {/* Valid capture highlight */}
                      {isValidTarget && piece && (
                        <div className="absolute inset-0 rounded-full ring-2 ring-inset ring-white/40" />
                      )}
                      {/* Piece */}
                      {piece && (
                        <Piece
                          isPlayer={isRed(piece)}
                          isKingPiece={isKing(piece)}
                          isSelected={isSelectedCell}
                          skin={skin}
                        />
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {aiThinking && (
              <div className="absolute inset-0 bg-background/40 flex items-center justify-center">
                <div className="bg-card px-4 py-2 rounded-lg border border-border text-sm font-serif text-primary animate-pulse">
                  AI думает…
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Side panel */}
        <div className="w-full lg:w-68 flex flex-col gap-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-xl bg-card border border-border text-center">
              <div className="text-2xl font-serif text-primary font-bold">{redCount}</div>
              <div className="text-xs text-muted-foreground mt-1">Ваши</div>
              <div className="flex justify-center mt-2">
                <div
                  className="w-5 h-5 rounded-full"
                  style={{ background: skin.playerGradient, boxShadow: skin.playerShadow }}
                />
              </div>
            </div>
            <div className="p-4 rounded-xl bg-card border border-border text-center">
              <div className="text-2xl font-serif text-foreground font-bold">{blackCount}</div>
              <div className="text-xs text-muted-foreground mt-1">AI</div>
              <div className="flex justify-center mt-2">
                <div
                  className="w-5 h-5 rounded-full"
                  style={{ background: skin.aiGradient, boxShadow: skin.aiShadow }}
                />
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-card border border-border">
            <div className="text-xs text-muted-foreground mb-1">Статус</div>
            {gameOver ? (
              <div className={`font-serif text-lg font-bold ${gameOver === "win" ? "text-primary" : "text-secondary"}`}>
                {gameOver === "win" ? "Вы победили!" : "AI победил"}
              </div>
            ) : (
              <div className="font-serif text-sm">
                {aiThinking
                  ? <span className="text-muted-foreground">AI думает…</span>
                  : <span className={turn === RED ? "text-primary" : "text-muted-foreground"}>
                      {turn === RED ? "Ваш ход" : "Ход AI"}
                    </span>
                }
              </div>
            )}
            <div className="text-xs text-muted-foreground mt-2">Ходов: {moveCount}</div>
          </div>

          <div className="p-4 rounded-xl bg-card border border-border">
            <div className="text-xs text-muted-foreground mb-3">Сложность</div>
            <div className="flex gap-2">
              {(["easy", "medium", "hard"] as Difficulty[]).map(d => (
                <button
                  key={d}
                  data-testid={`difficulty-${d}`}
                  onClick={() => { setDifficulty(d); resetGame(); }}
                  className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                    difficulty === d
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {d === "easy" ? "Лёгкий" : d === "medium" ? "Средний" : "Сложный"}
                </button>
              ))}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-card border border-border">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-muted-foreground">Скин</div>
                <div className="text-sm font-serif font-medium mt-0.5">{skin.name}</div>
              </div>
              <button
                onClick={() => setLocation("/pro")}
                className="text-xs text-primary hover:underline"
              >
                Сменить →
              </button>
            </div>
          </div>

          <Button data-testid="button-new-game" onClick={resetGame} variant="outline" className="w-full font-serif">
            Новая игра
          </Button>
          <button
            onClick={() => setLocation("/play/friend")}
            className="w-full py-3 border border-border rounded-xl text-sm hover:bg-muted/50 transition-colors"
          >
            Играть с другом по ссылке
          </button>
        </div>
      </div>

      {showResult && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl p-8 text-center max-w-sm w-full shadow-2xl">
            <div className={`font-serif text-5xl mb-4 ${gameOver === "win" ? "text-primary" : "text-secondary"}`}>
              {gameOver === "win" ? "✦" : "◆"}
            </div>
            <h2 className={`font-serif text-3xl font-bold mb-2 ${gameOver === "win" ? "text-primary" : "text-secondary"}`}>
              {gameOver === "win" ? "Победа!" : "Поражение"}
            </h2>
            <p className="text-muted-foreground mb-6 text-sm">
              {gameOver === "win" ? `Выиграно за ${moveCount} ходов` : "AI победил. Попробуйте ещё раз!"}
            </p>
            <div className="flex gap-3">
              <Button onClick={resetGame} className="flex-1 font-serif">Ещё раз</Button>
              <Button variant="outline" onClick={() => { setShowResult(false); setLocation("/"); }} className="flex-1">
                Меню
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
