import { useState } from "react";
import { useLocation } from "wouter";
import { Show } from "@clerk/react";
import { SKINS, getSkin, setActiveSkinId, getActiveSkinId, type Skin } from "@/lib/skins";

function MiniBoard({ skin, size = 120 }: { skin: Skin; size?: number }) {
  const layout = [
    [null, "ai",  null, "ai" ],
    ["ai",  null, "ai",  null],
    [null, null,  null, null ],
    [null, null,  null, null ],
    [null, null,  null, null ],
    [null, null,  null, null ],
    [null, "pl",  null, "pl" ],
    ["pl",  null, "pl",  null],
  ];

  return (
    <div
      className="rounded-lg overflow-hidden"
      style={{
        width: size,
        height: size,
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gridTemplateRows: "repeat(4, 1fr)",
        border: `2px solid ${skin.boardDark}`,
        boxShadow: skin.glow ?? "0 4px 20px rgba(0,0,0,0.5)",
        flexShrink: 0,
      }}
    >
      {layout.slice(0, 4).map((row, r) =>
        row.map((cell, c) => {
          const isDark = (r + c) % 2 === 1;
          const isPlayer = cell === "pl";
          const isAi = cell === "ai";
          return (
            <div
              key={`${r}-${c}`}
              className="relative overflow-hidden"
              style={{ backgroundColor: isDark ? skin.boardDark : skin.boardLight }}
            >
              {(isPlayer || isAi) && (
                <div
                  className="absolute rounded-full"
                  style={{
                    inset: "10%",
                    background: isPlayer ? skin.playerGradient : skin.aiGradient,
                    boxShadow: isPlayer ? skin.playerShadow : skin.aiShadow,
                  }}
                >
                  <div
                    className="absolute inset-0 rounded-full"
                    style={{ background: isPlayer ? skin.playerReflect : skin.aiReflect }}
                  />
                </div>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}

function SkinCard({
  skin,
  isActive,
  onSelect,
}: {
  skin: Skin;
  isActive: boolean;
  onSelect: () => void;
}) {
  return (
    <div
      onClick={!skin.locked ? onSelect : undefined}
      className={`relative rounded-2xl border p-4 transition-all group overflow-hidden
        ${skin.locked ? "opacity-70 cursor-default" : "cursor-pointer hover:scale-[1.02]"}
        ${isActive ? "border-primary/60 bg-primary/5" : "border-border/50 bg-card hover:border-border"}
      `}
    >
      {/* Lock badge */}
      {skin.locked && (
        <div className="absolute top-3 right-3 w-7 h-7 rounded-full bg-muted border border-border flex items-center justify-center z-10">
          <span className="text-sm">🔒</span>
        </div>
      )}
      {/* Active badge */}
      {isActive && (
        <div className="absolute top-3 right-3 w-7 h-7 rounded-full bg-primary flex items-center justify-center z-10">
          <span className="text-primary-foreground text-xs font-bold">✓</span>
        </div>
      )}

      {/* Mini board preview */}
      <div className="flex justify-center mb-4">
        <MiniBoard skin={skin} size={110} />
      </div>

      <div className="text-center">
        <div className="font-serif font-bold text-base">{skin.name}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{skin.subtitle}</div>
      </div>

      {/* Piece pair strip */}
      <div className="flex items-center justify-center gap-3 mt-3">
        <div className="flex items-center gap-1.5">
          <div
            className="w-5 h-5 rounded-full"
            style={{ background: skin.playerGradient, boxShadow: skin.playerShadow }}
          />
          <span className="text-xs text-muted-foreground">Игрок</span>
        </div>
        <div className="w-px h-4 bg-border" />
        <div className="flex items-center gap-1.5">
          <div
            className="w-5 h-5 rounded-full"
            style={{ background: skin.aiGradient, boxShadow: skin.aiShadow }}
          />
          <span className="text-xs text-muted-foreground">AI</span>
        </div>
      </div>

      {!skin.locked && !isActive && (
        <div className="mt-3 text-center text-xs text-primary font-medium opacity-0 group-hover:opacity-100 transition-opacity">
          Нажми чтобы выбрать
        </div>
      )}
      {skin.locked && (
        <div className="mt-3 text-center">
          <span className="text-xs px-2 py-0.5 rounded-full border border-primary/30 bg-primary/10 text-primary font-medium">
            PRO
          </span>
        </div>
      )}
    </div>
  );
}

const proFeatures = [
  {
    icon: "◆",
    title: "6 уникальных скинов",
    desc: "Каждый скин — полноценная смена визуального стиля: фигуры, доска, эффекты свечения. Не просто цвет — другая атмосфера.",
  },
  {
    icon: "◈",
    title: "AI Тренер",
    desc: "После каждой партии AI разбирает твои ходы: где упустил победу, где сыграл лучше всего.",
  },
  {
    icon: "◉",
    title: "Детальная аналитика",
    desc: "График роста рейтинга, карта типичных ошибок, рекомендуемые упражнения для улучшения игры.",
  },
  {
    icon: "⟡",
    title: "Расширенная история",
    desc: "Полная история всех партий без ограничений с возможностью просмотра любого хода.",
  },
];

export default function Pro() {
  const [, setLocation] = useLocation();
  const [activeSkinId, setActiveSkinIdState] = useState(() => getActiveSkinId());
  const [justSelected, setJustSelected] = useState<string | null>(null);

  const handleSelect = (skinId: string) => {
    setActiveSkinId(skinId);
    setActiveSkinIdState(skinId);
    setJustSelected(skinId);
    setTimeout(() => setJustSelected(null), 1500);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex items-center justify-between px-6 py-4 border-b border-border/40">
        <button onClick={() => setLocation("/")} className="font-serif text-xl text-primary tracking-widest">DAMA</button>
        <div className="flex items-center gap-4">
          <button onClick={() => setLocation("/play")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Играть
          </button>
          <Show when="signed-in">
            <button onClick={() => setLocation("/profile")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Профиль
            </button>
          </Show>
        </div>
      </div>

      {/* Preview banner */}
      <div className="bg-primary/8 border-b border-primary/15 px-6 py-3 text-center">
        <span className="text-xs text-primary/80 font-medium tracking-wider">
          РЕЖИМ ПРЕДПРОСМОТРА — Скин «Классик» доступен бесплатно, остальные — с Pro подпиской
        </span>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        {/* Hero */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-medium mb-6 tracking-wider">
            DAMA PRO
          </div>
          <h1 className="font-serif text-5xl sm:text-6xl font-bold mb-4">
            Твой стиль —<br />
            <span className="text-primary">твоя игра</span>
          </h1>
          <p className="text-muted-foreground text-xl max-w-xl mx-auto leading-relaxed">
            Каждый скин меняет не только цвет фигур — это другое освещение, другая доска, другой характер партии.
          </p>
        </div>

        {/* Skin grid */}
        <div className="mb-16">
          <h2 className="font-serif text-2xl mb-2">Скины фигур и доски</h2>
          <p className="text-muted-foreground text-sm mb-7">Выбери стиль игры — он применится сразу в следующей партии</p>

          {justSelected && (
            <div className="mb-5 p-3 rounded-xl bg-primary/10 border border-primary/25 text-center text-sm text-primary font-medium">
              Скин «{getSkin(justSelected).name}» применён — запускай игру!
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {SKINS.map(skin => (
              <SkinCard
                key={skin.id}
                skin={skin}
                isActive={activeSkinId === skin.id}
                onSelect={() => handleSelect(skin.id)}
              />
            ))}
          </div>
        </div>

        {/* AI Coach preview */}
        <div className="mb-16 p-8 rounded-2xl border border-primary/15 bg-card relative overflow-hidden">
          <div className="absolute inset-0 bg-primary/2 pointer-events-none" />
          <div className="relative">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
                <span className="font-serif text-primary font-bold text-sm">AI</span>
              </div>
              <div>
                <div className="font-serif font-bold">AI Тренер</div>
                <div className="text-xs text-muted-foreground">Разбор партии</div>
              </div>
              <div className="ml-auto px-2.5 py-1 rounded-full bg-primary/20 border border-primary/30 text-xs text-primary font-semibold">
                PRO
              </div>
            </div>
            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-muted/50 text-sm leading-relaxed">
                <span className="text-primary font-semibold">Ход 8: </span>
                <span className="text-muted-foreground">Сильнее было e3→f4 — это создавало угрозу двойного взятия через ход.</span>
              </div>
              <div className="p-3.5 rounded-xl bg-muted/50 text-sm leading-relaxed">
                <span className="text-primary font-semibold">Совет: </span>
                <span className="text-muted-foreground">Ваши шашки на флангах изолированы. Центральный контроль был бы выгоднее с хода 5.</span>
              </div>
              <div className="p-3.5 rounded-xl bg-muted/50 text-sm leading-relaxed">
                <span className="text-primary font-semibold">Лучший момент: </span>
                <span className="text-muted-foreground">Ход 14 — отличный выбор! Серия из двух взятий переломила ход партии.</span>
              </div>
              <div className="p-3.5 rounded-xl bg-muted/30 border border-border/50 text-sm text-center text-muted-foreground select-none filter blur-sm">
                Ещё 6 советов скрыты — оформи Pro чтобы увидеть полный разбор
              </div>
            </div>
          </div>
        </div>

        {/* Features grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-16">
          {proFeatures.map(f => (
            <div key={f.title} className="p-6 rounded-2xl border border-border/50 bg-card hover:border-primary/25 transition-all">
              <div className="text-2xl text-primary font-serif mb-3">{f.icon}</div>
              <h3 className="font-serif text-base font-bold mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <div className="text-center">
          <div className="inline-block p-8 rounded-2xl border-2 border-primary/35 bg-card shadow-xl shadow-primary/5 max-w-sm w-full">
            <div className="font-serif text-4xl font-bold text-primary mb-1">Pro</div>
            <div className="text-muted-foreground text-sm mb-6">Все скины + AI тренер + аналитика</div>
            <div className="text-4xl font-serif font-bold mb-1">$9.99<span className="text-lg text-muted-foreground">/мес</span></div>
            <div className="text-xs text-muted-foreground mb-7">или $79.99/год — экономия 33%</div>
            <Show when="signed-out">
              <button
                onClick={() => setLocation("/sign-up")}
                className="w-full py-3.5 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 transition-all font-serif mb-3"
              >
                Создать аккаунт
              </button>
            </Show>
            <Show when="signed-in">
              <button
                data-testid="button-upgrade-pro"
                className="w-full py-3.5 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 transition-all font-serif mb-3"
              >
                Оформить Pro подписку
              </button>
            </Show>
            <p className="text-xs text-muted-foreground">Отмена в любое время · Без скрытых платежей</p>
          </div>
        </div>
      </div>
    </div>
  );
}
