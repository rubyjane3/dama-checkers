import { useLocation } from "wouter";
import { Show } from "@clerk/react";

export default function Landing() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4 border-b border-border/40 backdrop-blur-md bg-background/80">
        <span className="font-serif text-2xl text-primary tracking-widest">DAMA</span>
        <div className="hidden sm:flex items-center gap-6 text-sm text-muted-foreground">
          <button onClick={() => setLocation("/play")} className="hover:text-foreground transition-colors">Играть</button>
          <button onClick={() => setLocation("/kids")} className="hover:text-foreground transition-colors">Детский режим</button>
          <button onClick={() => setLocation("/leaderboard")} className="hover:text-foreground transition-colors">Рейтинг</button>
          <button onClick={() => setLocation("/pro")} className="hover:text-foreground transition-colors text-primary">Pro</button>
        </div>
        <div className="flex items-center gap-3">
          <Show when="signed-out">
            <button
              data-testid="button-signin"
              onClick={() => setLocation("/sign-in")}
              className="px-4 py-2 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors"
            >
              Войти
            </button>
            <button
              data-testid="button-signup"
              onClick={() => setLocation("/sign-up")}
              className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 font-semibold transition-colors"
            >
              Начать
            </button>
          </Show>
          <Show when="signed-in">
            <button
              data-testid="button-play"
              onClick={() => setLocation("/play")}
              className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 font-semibold transition-colors"
            >
              Играть
            </button>
          </Show>
        </div>
      </nav>

      {/* Hero */}
      <section className="min-h-screen flex flex-col items-center justify-center px-6 pt-24 pb-16 relative">
        {/* Ambient glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-3xl" />
          <div className="absolute top-1/2 left-1/4 w-[300px] h-[300px] rounded-full bg-secondary/5 blur-3xl" />
        </div>

        <div className="text-center max-w-4xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-medium mb-8 tracking-wider">
            МАСТЕРСТВО ИГРЫ
          </div>
          <h1 className="font-serif text-5xl sm:text-7xl lg:text-8xl font-bold text-foreground leading-none tracking-tight mb-6">
            Думай наперёд —<br/>
            <span className="text-primary">побеждай</span>
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Платформа нового поколения: умный AI-соперник, игра с другом, детский обучающий режим и глобальный рейтинг.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              data-testid="button-play-now"
              onClick={() => setLocation("/play")}
              className="w-full sm:w-auto px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 transition-all hover:scale-105 active:scale-95 text-lg shadow-lg shadow-primary/20"
            >
              Играть сейчас
            </button>
            <button
              data-testid="button-kids-mode"
              onClick={() => setLocation("/kids")}
              className="w-full sm:w-auto px-8 py-4 border border-border text-foreground font-semibold rounded-xl hover:bg-muted/50 transition-all text-lg"
            >
              Детский режим
            </button>
          </div>
        </div>

        {/* Mini 3D board preview */}
        <div className="perspective-board mt-16 relative">
          <div className="tilt-board w-48 h-48 sm:w-64 sm:h-64 rounded-xl overflow-hidden grid grid-cols-8">
            {Array.from({ length: 64 }).map((_, i) => {
              const row = Math.floor(i / 8);
              const col = i % 8;
              const isDark = (row + col) % 2 === 1;
              const hasPiece = isDark && (
                (row < 3 && (row + col) % 2 === 1) ||
                (row > 4 && (row + col) % 2 === 1)
              );
              const isRed = hasPiece && row > 4;
              return (
                <div
                  key={i}
                  className={`${isDark ? "bg-[#2a1a0a]" : "bg-[#d4a96a]"} flex items-center justify-center`}
                >
                  {hasPiece && (
                    <div className={`w-[70%] h-[70%] rounded-full piece ${isRed ? "red" : "black"}`} />
                  )}
                </div>
              );
            })}
          </div>
          <div className="absolute -inset-4 rounded-2xl bg-primary/5 blur-xl pointer-events-none" />
        </div>
      </section>

      {/* Features */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-serif text-3xl sm:text-4xl text-center mb-16">Почему выбирают DAMA?</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Умный AI",
                desc: "Три уровня сложности — от новичка до гроссмейстера. Минимакс-алгоритм с альфа-бета отсечением.",
                icon: "◈",
              },
              {
                title: "Игра с другом",
                desc: "Создай комнату и поделись ссылкой — играй с другом в любой точке мира.",
                icon: "⟡",
              },
              {
                title: "Детский режим",
                desc: "6 обучающих уроков с пошаговыми объяснениями для детей. Безопасно, весело, эффективно.",
                icon: "✦",
              },
              {
                title: "Глобальный рейтинг",
                desc: "Соревнуйся с игроками со всего Казахстана и мира. Следи за своим местом в таблице.",
                icon: "◉",
              },
              {
                title: "3D доска",
                desc: "Уникальная перспективная доска с объёмными фигурами — игра как в реальности.",
                icon: "◬",
              },
              {
                title: "Pro режим",
                desc: "Уникальные темы, аналитика игр, тренер на основе AI. Для тех, кто хочет большего.",
                icon: "◆",
              },
            ].map((f) => (
              <div
                key={f.title}
                className="p-6 rounded-2xl border border-border/50 bg-card hover:border-primary/30 hover:bg-card/80 transition-all group"
              >
                <div className="text-3xl text-primary mb-4 font-serif">{f.icon}</div>
                <h3 className="font-serif text-lg mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 text-center border-t border-border/30">
        <div className="max-w-2xl mx-auto">
          <h2 className="font-serif text-4xl sm:text-5xl mb-6">Готов к игре?</h2>
          <p className="text-muted-foreground text-lg mb-10">Присоединяйся к тысячам игроков уже сегодня.</p>
          <Show when="signed-out">
            <button
              onClick={() => setLocation("/sign-up")}
              className="px-10 py-4 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 text-lg transition-all hover:scale-105 shadow-lg shadow-primary/20"
            >
              Создать аккаунт бесплатно
            </button>
          </Show>
          <Show when="signed-in">
            <button
              onClick={() => setLocation("/play")}
              className="px-10 py-4 bg-primary text-primary-foreground font-semibold rounded-xl hover:bg-primary/90 text-lg transition-all hover:scale-105 shadow-lg shadow-primary/20"
            >
              Играть сейчас
            </button>
          </Show>
        </div>
      </section>

      <footer className="border-t border-border/30 py-8 px-6 text-center text-sm text-muted-foreground">
        <span className="font-serif text-primary mr-4">DAMA</span>
        Русские шашки нового поколения · 2026
      </footer>
    </div>
  );
}
