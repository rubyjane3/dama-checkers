import { useState } from "react";
import { useLocation } from "wouter";
import { useGetLeaderboard, useGetLeaderboardSummary } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const cities = ["Все города", "Алматы", "Астана", "Шымкент", "Актобе", "Павлодар"];

export default function Leaderboard() {
  const [, setLocation] = useLocation();
  const [city, setCity] = useState("all");

  const { data: entries, isLoading } = useGetLeaderboard({ limit: 50 });
  const { data: summary } = useGetLeaderboardSummary();

  const filtered = city === "all"
    ? entries
    : entries?.filter(e => e.city === city);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex items-center justify-between px-6 py-4 border-b border-border/40">
        <button onClick={() => setLocation("/")} className="font-serif text-xl text-primary tracking-widest">DAMA</button>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <button onClick={() => setLocation("/play")} className="hover:text-foreground transition-colors">Играть</button>
          <button onClick={() => setLocation("/profile")} className="hover:text-foreground transition-colors">Профиль</button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-6 py-10">
        <div className="text-center mb-10">
          <div className="text-primary text-4xl font-serif mb-3">◉</div>
          <h1 className="font-serif text-4xl font-bold mb-2">Рейтинг игроков</h1>
          <p className="text-muted-foreground">Лучшие шашисты платформы</p>
        </div>

        {/* Summary stats */}
        {summary && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
            {[
              { label: "Игроков", value: summary.totalPlayers.toLocaleString() },
              { label: "Средний рейтинг", value: Math.round(summary.avgRating).toString() },
              { label: "Лучший город", value: summary.topCity ?? "—" },
              { label: "Игр сыграно", value: summary.totalGamesPlayed.toLocaleString() },
            ].map(s => (
              <div key={s.label} className="p-3 rounded-xl bg-card border border-border text-center">
                <div className="font-serif text-lg font-bold text-primary">{s.value}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* City filter */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-serif text-lg">Топ игроков</h2>
          <Select value={city} onValueChange={setCity}>
            <SelectTrigger data-testid="select-city" className="w-44 text-sm">
              <SelectValue placeholder="Город" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все города</SelectItem>
              {cities.slice(1).map(c => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Table */}
        <div className="rounded-2xl border border-border overflow-hidden">
          <div className="grid grid-cols-[48px_1fr_80px_80px] px-4 py-3 bg-muted/50 text-xs text-muted-foreground font-medium">
            <div>#</div>
            <div>Игрок</div>
            <div className="text-right">Победы</div>
            <div className="text-right">Рейтинг</div>
          </div>

          {isLoading ? (
            Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="px-4 py-3 border-t border-border">
                <Skeleton className="h-8 w-full" />
              </div>
            ))
          ) : filtered?.length === 0 ? (
            <div className="px-4 py-8 text-center text-muted-foreground text-sm">
              Нет игроков по выбранному фильтру
            </div>
          ) : (
            filtered?.map((entry, idx) => (
              <div
                key={entry.userId}
                data-testid={`leaderboard-row-${entry.userId}`}
                className={`grid grid-cols-[48px_1fr_80px_80px] px-4 py-3.5 border-t border-border items-center
                  ${idx < 3 ? "bg-primary/3" : "hover:bg-muted/30"}
                  transition-colors`}
              >
                <div className="font-serif text-sm font-bold">
                  {idx === 0 ? <span className="text-yellow-400">◆</span>
                   : idx === 1 ? <span className="text-zinc-400">◆</span>
                   : idx === 2 ? <span className="text-amber-700">◆</span>
                   : <span className="text-muted-foreground">{entry.rank}</span>}
                </div>
                <div>
                  <div className="font-medium text-sm">{entry.username}</div>
                  {entry.city && <div className="text-xs text-muted-foreground">{entry.city}</div>}
                </div>
                <div className="text-right text-sm font-medium">{entry.wins}</div>
                <div className="text-right">
                  <span className="font-serif text-sm font-bold text-primary">{entry.rating}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
