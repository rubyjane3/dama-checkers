import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useGetLesson, useUpdateLessonProgress, getGetMyLessonProgressQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { initBoard, type Board } from "@/lib/game";
import { Show } from "@clerk/react";

export default function KidsLesson() {
  const [, setLocation] = useLocation();
  const params = useParams<{ id: string }>();
  const lessonId = Number(params.id);
  const [step, setStep] = useState(0);
  const [completed, setCompleted] = useState(false);
  const qc = useQueryClient();

  const { data: lesson, isLoading } = useGetLesson(lessonId);

  const updateProgress = useUpdateLessonProgress();

  const totalSteps = lesson?.totalSteps ?? 0;
  const steps: { title: string; content: string }[] = lesson
    ? Array.from({ length: totalSteps }, (_, i) => ({
        title: `Шаг ${i + 1}`,
        content: i === 0
          ? lesson.content
          : `Практика шага ${i + 1}: Попробуй применить то, что ты узнал на доске ниже.`,
      }))
    : [];

  const handleNext = () => {
    const newStep = step + 1;
    if (newStep >= steps.length) {
      setCompleted(true);
      updateProgress.mutate(
        { id: lessonId, data: { stepsCompleted: totalSteps, completed: true } },
        { onSuccess: () => qc.invalidateQueries({ queryKey: getGetMyLessonProgressQueryKey() }) }
      );
    } else {
      setStep(newStep);
      updateProgress.mutate(
        { id: lessonId, data: { stepsCompleted: newStep, completed: false } },
        { onSuccess: () => qc.invalidateQueries({ queryKey: getGetMyLessonProgressQueryKey() }) }
      );
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <Skeleton className="h-8 w-48 mb-4" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">Урок не найден</p>
          <button onClick={() => setLocation("/kids")} className="mt-4 text-primary hover:underline text-sm">
            Назад к урокам
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex items-center justify-between px-6 py-4 border-b border-border/40">
        <button onClick={() => setLocation("/kids")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
          ← К урокам
        </button>
        <span className="font-serif text-primary">DAMA — Детский режим</span>
      </div>

      <div className="max-w-3xl mx-auto px-6 py-10">
        {/* Lesson header */}
        <div className="mb-8">
          <div className="text-xs text-muted-foreground mb-2">Урок {lesson.order}</div>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold mb-3">{lesson.title}</h1>
          <p className="text-muted-foreground">{lesson.description}</p>
        </div>

        {/* Step progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            <span>Прогресс</span>
            <span>{step + 1} из {steps.length}</span>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${((step + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {completed ? (
          /* Completion screen */
          <div className="text-center py-16">
            <div className="text-6xl font-serif text-primary mb-4">✦</div>
            <h2 className="font-serif text-3xl font-bold mb-3">Урок пройден!</h2>
            <p className="text-muted-foreground mb-8">Отличная работа! Ты освоил этот урок.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={() => setLocation("/kids")} variant="outline" className="font-serif">
                К списку уроков
              </Button>
              <Button onClick={() => setLocation("/play")} className="font-serif">
                Попробовать сыграть
              </Button>
            </div>
          </div>
        ) : (
          <>
            {/* Step content */}
            <div className="p-6 rounded-2xl bg-card border border-border mb-6">
              <h2 className="font-serif text-xl font-bold mb-4">{steps[step]?.title}</h2>
              <p className="text-foreground/90 leading-relaxed">{steps[step]?.content}</p>
            </div>

            {/* Mini practice board */}
            <div className="mb-6">
              <div className="text-sm text-muted-foreground mb-3">Доска для практики</div>
              <div className="rounded-xl overflow-hidden border-2 border-[#3d2b0e] max-w-[320px]" style={{ aspectRatio: "1/1" }}>
                <div className="grid grid-cols-8 w-full h-full">
                  {initBoard().map((row, r) =>
                    row.map((piece, c) => {
                      const isDark = (r + c) % 2 === 1;
                      const isRed = piece === "red" || piece === "red_king";
                      return (
                        <div
                          key={`${r}-${c}`}
                          className={`flex items-center justify-center ${isDark ? "bg-[#2a1a0a]" : "bg-[#d4a96a]"}`}
                        >
                          {piece && (
                            <div className={`w-[72%] h-[72%] rounded-full piece ${isRed ? "red" : "black"}`} />
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>

            <Show when="signed-in">
              <Button
                data-testid="button-next-step"
                onClick={handleNext}
                className="w-full font-serif"
                disabled={updateProgress.isPending}
              >
                {step + 1 >= steps.length ? "Завершить урок" : "Следующий шаг"}
              </Button>
            </Show>
            <Show when="signed-out">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-3">Войдите чтобы сохранять прогресс</p>
                <button onClick={() => setLocation("/sign-in")} className="px-5 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg">
                  Войти
                </button>
              </div>
            </Show>
          </>
        )}
      </div>
    </div>
  );
}
