export const BOARD_SIZE = 8;
export const EMPTY = null;
export const RED = "red";
export const BLACK = "black";
export const RED_KING = "red_king";
export const BLACK_KING = "black_king";

export type Piece = typeof RED | typeof BLACK | typeof RED_KING | typeof BLACK_KING | null;
export type Board = Piece[][];

export function initBoard(): Board {
  const board: Board = Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(EMPTY));
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if ((r + c) % 2 === 1) board[r][c] = BLACK;
    }
  }
  for (let r = 5; r < 8; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if ((r + c) % 2 === 1) board[r][c] = RED;
    }
  }
  return board;
}

export function isRed(p: Piece) { return p === RED || p === RED_KING; }
export function isBlack(p: Piece) { return p === BLACK || p === BLACK_KING; }
export function isKing(p: Piece) { return p === RED_KING || p === BLACK_KING; }
export function belongs(p: Piece, color: string) { return color === RED ? isRed(p) : isBlack(p); }
export function opponent(color: string) { return color === RED ? BLACK : RED; }

export type Move = {
  from: [number, number];
  to: [number, number];
  captured: [number, number] | null;
};

export function getJumps(board: Board, r: number, c: number, color: string, capturedSet = new Set<string>()): Move[] {
  const piece = board[r][c];
  const king = isKing(piece);
  const jumps: Move[] = [];
  const dirs = [[-1,-1],[-1,1],[1,-1],[1,1]];

  for (const [dr, dc] of dirs) {
    if (!king) {
      const er = r + dr, ec = c + dc;
      const lr = r + 2*dr, lc = c + 2*dc;
      if (er < 0 || er >= 8 || ec < 0 || ec >= 8) continue;
      if (lr < 0 || lr >= 8 || lc < 0 || lc >= 8) continue;
      const ekey = `${er},${ec}`;
      const enemy = board[er][ec];
      if (enemy && !belongs(enemy, color) && !capturedSet.has(ekey) && board[lr][lc] === EMPTY) {
        jumps.push({ from: [r,c], to: [lr,lc], captured: [er,ec] });
      }
    } else {
      let nr = r + dr, nc = c + dc;
      let enemyPos: [number, number] | null = null;

      while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
        const cell = board[nr][nc];
        const key = `${nr},${nc}`;

        if (enemyPos === null) {
          if (cell === EMPTY) { nr += dr; nc += dc; continue; }
          if (belongs(cell, color)) break;
          if (capturedSet.has(key)) break;
          enemyPos = [nr, nc];
          nr += dr; nc += dc;
        } else {
          if (cell !== EMPTY) break;
          jumps.push({ from: [r,c], to: [nr,nc], captured: enemyPos });
          nr += dr; nc += dc;
        }
      }
    }
  }
  return jumps;
}

export function getMoves(board: Board, r: number, c: number, color: string): Move[] {
  const piece = board[r][c];
  const king = isKing(piece);
  const dirs = king
    ? [[-1,-1],[-1,1],[1,-1],[1,1]]
    : color === RED ? [[-1,-1],[-1,1]] : [[1,-1],[1,1]];
  const moves: Move[] = [];

  for (const [dr, dc] of dirs) {
    let nr = r + dr, nc = c + dc;
    while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
      if (board[nr][nc] !== EMPTY) break;
      moves.push({ from: [r,c], to: [nr,nc], captured: null });
      if (!king) break;
      nr += dr; nc += dc;
    }
  }
  return moves;
}

export function getAllMoves(board: Board, color: string): Move[] {
  const jumps: Move[] = [];
  const moves: Move[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (board[r][c] && belongs(board[r][c], color)) {
        jumps.push(...getJumps(board, r, c, color, new Set()));
        moves.push(...getMoves(board, r, c, color));
      }
    }
  }
  return jumps.length > 0 ? jumps : moves;
}

export function applyMove(board: Board, move: Move): Board {
  const nb = board.map(r => [...r]);
  const [fr, fc] = move.from;
  const [tr, tc] = move.to;
  let piece = nb[fr][fc];
  nb[fr][fc] = EMPTY;
  if (move.captured) nb[move.captured[0]][move.captured[1]] = EMPTY;
  if (piece === RED && tr === 0) piece = RED_KING;
  if (piece === BLACK && tr === 7) piece = BLACK_KING;
  nb[tr][tc] = piece;
  return nb;
}

export function evaluate(board: Board): number {
  let score = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p) continue;
      if (p === RED) score -= (5 + (7 - r) * 0.3);
      else if (p === RED_KING) score -= 8;
      else if (p === BLACK) score += (5 + r * 0.3);
      else if (p === BLACK_KING) score += 8;
    }
  }
  return score;
}

export function minimax(board: Board, depth: number, alpha: number, beta: number, maximizing: boolean): number {
  const color = maximizing ? BLACK : RED;
  const moves = getAllMoves(board, color);
  if (depth === 0 || moves.length === 0) return evaluate(board);
  if (maximizing) {
    let best = -Infinity;
    for (const m of moves) {
      const nb = applyMove(board, m);
      const chains = m.captured ? getJumps(nb, m.to[0], m.to[1], BLACK) : [];
      const val = chains.length > 0
        ? minimax(nb, depth, alpha, beta, true)
        : minimax(nb, depth - 1, alpha, beta, false);
      best = Math.max(best, val);
      alpha = Math.max(alpha, val);
      if (beta <= alpha) break;
    }
    return best;
  } else {
    let best = Infinity;
    for (const m of moves) {
      const nb = applyMove(board, m);
      const chains = m.captured ? getJumps(nb, m.to[0], m.to[1], RED) : [];
      const val = chains.length > 0
        ? minimax(nb, depth, alpha, beta, false)
        : minimax(nb, depth - 1, alpha, beta, true);
      best = Math.min(best, val);
      beta = Math.min(beta, val);
      if (beta <= alpha) break;
    }
    return best;
  }
}

export function getBestMove(board: Board, difficulty: string): Move | null {
  const depth = difficulty === "easy" ? 1 : difficulty === "medium" ? 3 : 5;
  const moves = getAllMoves(board, BLACK);
  if (!moves.length) return null;
  if (difficulty === "easy" && Math.random() < 0.4) {
    return moves[Math.floor(Math.random() * moves.length)];
  }
  let best = -Infinity, bestMove = moves[0];
  for (const m of moves) {
    const nb = applyMove(board, m);
    const val = minimax(nb, depth - 1, -Infinity, Infinity, false);
    if (val > best) { best = val; bestMove = m; }
  }
  return bestMove;
}
