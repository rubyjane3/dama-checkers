export type Skin = {
  id: string;
  name: string;
  subtitle: string;
  locked: boolean;
  playerGradient: string;
  playerShadow: string;
  playerReflect: string;
  aiGradient: string;
  aiShadow: string;
  aiReflect: string;
  boardLight: string;
  boardDark: string;
  kingColor: string;
  glow?: string;
};

export const SKINS: Skin[] = [
  {
    id: "classic",
    name: "Классик",
    subtitle: "Тёплая слоновая кость",
    locked: false,
    playerGradient: "radial-gradient(circle at 32% 28%, #eddfc0 0%, #c4a47a 45%, #8b6442 100%)",
    playerShadow: "inset -4px -4px 10px rgba(0,0,0,0.45), inset 4px 4px 10px rgba(255,255,255,0.22), 0 5px 14px rgba(0,0,0,0.55)",
    playerReflect: "radial-gradient(ellipse at 35% 22%, rgba(255,255,255,0.45) 0%, transparent 55%)",
    aiGradient: "radial-gradient(circle at 32% 28%, #7a8290 0%, #3e4756 45%, #141b26 100%)",
    aiShadow: "inset -4px -4px 10px rgba(0,0,0,0.55), inset 4px 4px 10px rgba(255,255,255,0.08), 0 5px 14px rgba(0,0,0,0.65)",
    aiReflect: "radial-gradient(ellipse at 35% 22%, rgba(255,255,255,0.15) 0%, transparent 55%)",
    boardLight: "#d4a96a",
    boardDark: "#2a1a0a",
    kingColor: "#f5e8c0",
  },
  {
    id: "marble",
    name: "Мрамор",
    subtitle: "Белый каррарский / чёрный маркина",
    locked: true,
    playerGradient: `radial-gradient(circle at 32% 28%, #ffffff 0%, #ece8e2 40%, #d5cfc7 70%, #b8b0a6 100%)`,
    playerShadow: "inset -4px -4px 12px rgba(0,0,0,0.15), inset 4px 4px 12px rgba(255,255,255,0.75), 0 6px 20px rgba(0,0,0,0.35)",
    playerReflect: "radial-gradient(ellipse at 30% 20%, rgba(255,255,255,0.85) 0%, transparent 50%)",
    aiGradient: "radial-gradient(circle at 32% 28%, #3d3d3d 0%, #1c1c1c 40%, #0b0b0b 75%, #030303 100%)",
    aiShadow: "inset -4px -4px 12px rgba(0,0,0,0.8), inset 4px 4px 12px rgba(255,255,255,0.12), 0 6px 20px rgba(0,0,0,0.7)",
    aiReflect: "radial-gradient(ellipse at 30% 20%, rgba(255,255,255,0.18) 0%, transparent 50%)",
    boardLight: "#f2ede6",
    boardDark: "#161616",
    kingColor: "#c8a84b",
    glow: "0 0 30px rgba(200,190,180,0.1)",
  },
  {
    id: "gold",
    name: "Золото & Сталь",
    subtitle: "Расплавленное золото / полированная сталь",
    locked: true,
    playerGradient: "radial-gradient(circle at 28% 22%, #fff0a0 0%, #f5c518 25%, #d4920a 55%, #7a5500 100%)",
    playerShadow: "inset -4px -4px 10px rgba(0,0,0,0.35), inset 4px 4px 10px rgba(255,240,80,0.55), 0 0 22px rgba(245,197,24,0.45), 0 5px 14px rgba(0,0,0,0.5)",
    playerReflect: "radial-gradient(ellipse at 28% 18%, rgba(255,255,200,0.7) 0%, transparent 50%)",
    aiGradient: "radial-gradient(circle at 28% 22%, #cad5e0 0%, #7a8fa4 30%, #3d4f62 60%, #1a2535 100%)",
    aiShadow: "inset -4px -4px 10px rgba(0,0,0,0.5), inset 4px 4px 10px rgba(200,220,255,0.18), 0 5px 14px rgba(0,0,0,0.65)",
    aiReflect: "radial-gradient(ellipse at 28% 18%, rgba(220,235,255,0.35) 0%, transparent 50%)",
    boardLight: "#1e1500",
    boardDark: "#0c0900",
    kingColor: "#fff8c0",
    glow: "0 0 40px rgba(245,197,24,0.08)",
  },
  {
    id: "jade",
    name: "Нефрит",
    subtitle: "Зелёный нефрит / чёрный обсидиан",
    locked: true,
    playerGradient: "radial-gradient(circle at 30% 25%, #86efac 0%, #22c55e 28%, #15803d 58%, #052e16 100%)",
    playerShadow: "inset -4px -4px 10px rgba(0,0,0,0.45), inset 4px 4px 10px rgba(150,255,180,0.28), 0 0 20px rgba(34,197,94,0.3), 0 5px 14px rgba(0,0,0,0.55)",
    playerReflect: "radial-gradient(ellipse at 30% 20%, rgba(200,255,220,0.5) 0%, transparent 50%)",
    aiGradient: "radial-gradient(circle at 30% 25%, #1e2a38 0%, #0f1721 45%, #060d14 80%, #020609 100%)",
    aiShadow: "inset -4px -4px 10px rgba(0,0,0,0.75), inset 4px 4px 10px rgba(80,120,180,0.1), 0 5px 14px rgba(0,0,0,0.75)",
    aiReflect: "radial-gradient(ellipse at 30% 20%, rgba(100,160,220,0.12) 0%, transparent 50%)",
    boardLight: "#0a1f10",
    boardDark: "#040c07",
    kingColor: "#bbf7d0",
    glow: "0 0 30px rgba(34,197,94,0.07)",
  },
  {
    id: "ruby",
    name: "Рубин & Сапфир",
    subtitle: "Пылающий рубин / холодный сапфир",
    locked: true,
    playerGradient: "radial-gradient(circle at 30% 25%, #fecaca 0%, #ef4444 28%, #991b1b 58%, #450a0a 100%)",
    playerShadow: "inset -4px -4px 10px rgba(0,0,0,0.45), inset 4px 4px 10px rgba(255,180,180,0.28), 0 0 22px rgba(239,68,68,0.38), 0 5px 14px rgba(0,0,0,0.55)",
    playerReflect: "radial-gradient(ellipse at 30% 20%, rgba(255,220,220,0.55) 0%, transparent 50%)",
    aiGradient: "radial-gradient(circle at 30% 25%, #bfdbfe 0%, #3b82f6 28%, #1d4ed8 58%, #0c1a50 100%)",
    aiShadow: "inset -4px -4px 10px rgba(0,0,0,0.45), inset 4px 4px 10px rgba(180,210,255,0.28), 0 0 22px rgba(59,130,246,0.35), 0 5px 14px rgba(0,0,0,0.55)",
    aiReflect: "radial-gradient(ellipse at 30% 20%, rgba(210,230,255,0.45) 0%, transparent 50%)",
    boardLight: "#1a0606",
    boardDark: "#06060f",
    kingColor: "#fde68a",
    glow: "0 0 30px rgba(200,60,60,0.07)",
  },
  {
    id: "prism",
    name: "Призма",
    subtitle: "Голографический кристалл",
    locked: true,
    playerGradient: "conic-gradient(from 210deg at 50% 50%, #ff6b6b 0deg, #ffd93d 60deg, #6bcb77 120deg, #4d96ff 180deg, #c77dff 240deg, #ff6b6b 360deg)",
    playerShadow: "inset -4px -4px 10px rgba(0,0,0,0.25), inset 4px 4px 10px rgba(255,255,255,0.3), 0 0 28px rgba(180,100,255,0.45), 0 5px 14px rgba(0,0,0,0.4)",
    playerReflect: "radial-gradient(ellipse at 30% 20%, rgba(255,255,255,0.55) 0%, transparent 50%)",
    aiGradient: "conic-gradient(from 30deg at 50% 50%, #1a1a3e 0deg, #0d2156 60deg, #1a0a30 120deg, #0a1a40 180deg, #25103a 240deg, #1a1a3e 360deg)",
    aiShadow: "inset -4px -4px 10px rgba(0,0,0,0.65), inset 4px 4px 10px rgba(150,100,255,0.18), 0 0 22px rgba(83,52,131,0.35), 0 5px 14px rgba(0,0,0,0.65)",
    aiReflect: "radial-gradient(ellipse at 30% 20%, rgba(200,180,255,0.2) 0%, transparent 50%)",
    boardLight: "#080814",
    boardDark: "#030308",
    kingColor: "#f0f0ff",
    glow: "0 0 40px rgba(150,80,255,0.08)",
  },
];

export function getSkin(id: string): Skin {
  return SKINS.find(s => s.id === id) ?? SKINS[0];
}

export function getActiveSkinId(): string {
  try { return localStorage.getItem("dama_skin") ?? "classic"; } catch { return "classic"; }
}

export function setActiveSkinId(id: string) {
  try { localStorage.setItem("dama_skin", id); } catch { /* ignore */ }
}
